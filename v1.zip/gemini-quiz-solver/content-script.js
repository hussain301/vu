/**
 * content-script.js
 *
 * Buttons are camouflaged to blend with the page — nearly invisible,
 * styled to match surrounding elements. Only visible if you know where to look.
 */

// ─── Configuration ──────────────────────────────────────────────────────────────

const TARGET_XPATH = "/html/body/form/div[7]/div[2]/div[2]/div[3]/a[2]";
const DISABLED_SITES_KEY = "disabledSites";
const ANSWER_DISPLAY_XPATH = "/html/body/form/div[6]/div/div[2]/ul/li[2]/div/span/span[1]";

// ─── Utility: Resolve XPath ─────────────────────────────────────────────────────

function resolveXPath(xpath) {
  try {
    const result = document.evaluate(
      xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
    );
    return result.singleNodeValue;
  } catch (err) {
    return null;
  }
}

// ─── Utility: Detect page styles for camouflage ─────────────────────────────────

/**
 * Reads the computed styles of surrounding elements to blend our buttons in.
 * Returns style properties that match the page's look.
 */
function getPageStyles() {
  // Try to sample styles from the target element's sibling or nearby elements
  const targetEl = resolveXPath(TARGET_XPATH);
  const bodyStyle = window.getComputedStyle(document.body);

  if (targetEl) {
    const targetStyle = window.getComputedStyle(targetEl);
    return {
      fontFamily: targetStyle.fontFamily || bodyStyle.fontFamily,
      fontSize: targetStyle.fontSize || "12px",
      color: targetStyle.color || bodyStyle.color,
      bgColor: targetStyle.backgroundColor || "transparent",
      border: targetStyle.border || "none",
      padding: targetStyle.padding || "4px 8px",
      lineHeight: targetStyle.lineHeight || "normal",
    };
  }

  // Fallback: sample from body/first links
  const sampleLink = document.querySelector("a") || document.querySelector("button");
  if (sampleLink) {
    const s = window.getComputedStyle(sampleLink);
    return {
      fontFamily: s.fontFamily || bodyStyle.fontFamily,
      fontSize: s.fontSize || "12px",
      color: s.color || bodyStyle.color,
      bgColor: "transparent",
      border: "none",
      padding: "2px 4px",
      lineHeight: s.lineHeight || "normal",
    };
  }

  return {
    fontFamily: bodyStyle.fontFamily,
    fontSize: "11px",
    color: bodyStyle.color || "#666",
    bgColor: "transparent",
    border: "none",
    padding: "2px 4px",
    lineHeight: "normal",
  };
}

// ─── Disabled sites ─────────────────────────────────────────────────────────────

function getCurrentHost() { return window.location.hostname; }

function isSiteDisabled() {
  return new Promise((resolve) => {
    chrome.storage.local.get(DISABLED_SITES_KEY, (data) => {
      if (chrome.runtime.lastError) { resolve(false); return; }
      resolve((data[DISABLED_SITES_KEY] || []).includes(getCurrentHost()));
    });
  });
}

// ─── Create camouflaged solve button ────────────────────────────────────────────

/**
 * Creates the solve trigger — looks like an ordinary page element.
 * On XPath pages: looks like a tiny separator dot or link that blends in.
 * On other pages: a nearly invisible fixed element.
 */
function createSolveButton(mode) {
  const ps = getPageStyles();
  const btn = document.createElement("span");
  btn.id = "gqs-s";

  if (mode === "adjacent") {
    // Blend with the navigation buttons — looks like a tiny dot/separator
    btn.textContent = "·";
    Object.assign(btn.style, {
      fontFamily: ps.fontFamily,
      fontSize: ps.fontSize,
      color: "#2ed573",
      background: "transparent",
      border: "none",
      padding: "2px 5px",
      cursor: "default",
      display: "inline",
      verticalAlign: "middle",
      opacity: "1",
      userSelect: "none",
      lineHeight: ps.lineHeight,
      fontWeight: "bold",
    });
  } else {
    // Floating mode — nearly invisible pixel in the corner
    btn.textContent = "·";
    Object.assign(btn.style, {
      position: "fixed",
      bottom: "2px",
      right: "2px",
      fontFamily: "serif",
      fontSize: "24px",
      color: "#2ed573",
      background: "transparent",
      border: "none",
      padding: "1px",
      cursor: "default",
      zIndex: "2147483647",
      lineHeight: "1",
      userSelect: "none",
      opacity: "1",
      fontWeight: "bold",
    });
  }

  return btn;
}

/**
 * Creates the dismiss trigger — nearly invisible, blends with page.
 * Only shown in floating mode.
 */
function createDismissButton() {
  const btn = document.createElement("span");
  btn.id = "gqs-d";
  btn.textContent = "·";
  Object.assign(btn.style, {
    position: "fixed",
    bottom: "2px",
    right: "28px",
    fontFamily: "serif",
    fontSize: "24px",
    color: "#e74c5c",
    background: "transparent",
    border: "none",
    padding: "1px",
    cursor: "default",
    zIndex: "2147483647",
    lineHeight: "1",
    userSelect: "none",
    opacity: "1",
    fontWeight: "bold",
  });
  return btn;
}

// ─── Loading state ──────────────────────────────────────────────────────────────

let pipelineRunning = false;
let originalText = "·";

function setButtonLoading(btn) {
  pipelineRunning = true;
  originalText = btn.textContent;
  // Subtle change — just slightly different opacity
  btn.style.opacity = "0.3";
}

function setButtonReady(btn) {
  pipelineRunning = false;
  btn.textContent = originalText;
  btn.style.opacity = btn._origOpacity || "0.6";
}

// ─── Answer display ─────────────────────────────────────────────────────────────

function getOptionLetter(options, correctAnswer) {
  const letters = ["A", "B", "C", "D"];
  const idx = options.findIndex(
    (opt) => opt.trim().toLowerCase() === correctAnswer.trim().toLowerCase()
  );
  return idx !== -1 ? letters[idx] : correctAnswer;
}

function displayAnswer(letter) {
  const displayEl = resolveXPath(ANSWER_DISPLAY_XPATH);
  if (displayEl) {
    displayEl.textContent = displayEl.textContent + " " + letter;
    return;
  }

  // Fallback: tiny text at top-left, looks like a page artifact
  const el = document.createElement("span");
  el.id = "gqs-a";
  el.textContent = letter;
  Object.assign(el.style, {
    position: "fixed",
    top: "0",
    left: "0",
    padding: "1px 3px",
    fontSize: "10px",
    color: "rgba(0,0,0,0.35)",
    background: "transparent",
    zIndex: "2147483647",
    fontFamily: "inherit",
    pointerEvents: "none",
    userSelect: "none",
  });
  document.body.appendChild(el);
}

// ─── Solve handler ──────────────────────────────────────────────────────────────

async function onSolveClick(solveBtn) {
  if (pipelineRunning) return;

  const dismissBtn = document.getElementById("gqs-d");
  if (dismissBtn) dismissBtn.remove();

  setButtonLoading(solveBtn);

  chrome.runtime.sendMessage({ action: "captureNow" }, (response) => {
    if (chrome.runtime.lastError || !response || response.error) {
      setButtonReady(solveBtn);
      return;
    }

    const { options, correctAnswer } = response.result;
    const letter = getOptionLetter(options, correctAnswer);
    displayAnswer(letter);

    // Restore button quietly
    setTimeout(() => setButtonReady(solveBtn), 1500);
  });
}

// ─── Dismiss handler ────────────────────────────────────────────────────────────

function onDismissClick(dismissBtn, solveBtn) {
  if (dismissBtn) dismissBtn.remove();
  if (solveBtn) solveBtn.remove();
}

// ─── Main: inject ───────────────────────────────────────────────────────────────

let injected = false;

async function injectButtons(mode) {
  if (injected) return true;

  const solveBtn = createSolveButton(mode);
  solveBtn._origOpacity = solveBtn.style.opacity;

  solveBtn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    onSolveClick(solveBtn);
  });

  if (mode === "adjacent") {
    const targetNode = resolveXPath(TARGET_XPATH);
    if (!targetNode) return false;

    targetNode.parentNode.insertBefore(solveBtn, targetNode.nextSibling);
    injected = true;
    return true;
  }

  // Floating: add both solve + dismiss
  const dismissBtn = createDismissButton();
  dismissBtn.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    onDismissClick(dismissBtn, solveBtn);
  });

  document.body.appendChild(solveBtn);
  document.body.appendChild(dismissBtn);
  injected = true;
  return true;
}

// ─── Boot ───────────────────────────────────────────────────────────────────────

setTimeout(async () => {
  if (await injectButtons("adjacent")) return;

  const observer = new MutationObserver(async (_mutations, obs) => {
    if (injected) { obs.disconnect(); return; }
    if (await injectButtons("adjacent")) obs.disconnect();
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
  });

  setTimeout(async () => {
    if (!injected) {
      observer.disconnect();
      await injectButtons("floating");
    }
  }, 5000);
}, 100);
