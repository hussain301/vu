/**
 * options.js
 *
 * Logic for the extension's Options page.
 * Handles saving, loading, clearing, and toggling visibility of the Gemini API key.
 */

// ─── DOM References ─────────────────────────────────────────────────────────────

const apiKeyInput = document.getElementById("apiKey");
const saveBtn = document.getElementById("saveBtn");
const clearBtn = document.getElementById("clearBtn");
const toggleBtn = document.getElementById("toggleVisibility");
const statusEl = document.getElementById("status");

// ─── Status display helper ──────────────────────────────────────────────────────

/**
 * Displays a temporary status message.
 * @param {string} message - The message text.
 * @param {"success"|"error"} type - The status type.
 * @param {number} [durationMs=3000] - How long to show the message.
 */
function showStatus(message, type, durationMs = 3000) {
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
  clearTimeout(showStatus._timer);
  showStatus._timer = setTimeout(() => {
    statusEl.className = "status";
  }, durationMs);
}

// ─── Load existing key on page open ─────────────────────────────────────────────

chrome.storage.local.get("geminiApiKey", (data) => {
  if (data.geminiApiKey) {
    apiKeyInput.value = data.geminiApiKey;
  }
});

// ─── Save button ────────────────────────────────────────────────────────────────

saveBtn.addEventListener("click", () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    showStatus("Please enter an API key.", "error");
    return;
  }

  chrome.storage.local.set({ geminiApiKey: key }, () => {
    if (chrome.runtime.lastError) {
      showStatus(`Error saving: ${chrome.runtime.lastError.message}`, "error");
      return;
    }
    showStatus("✅ API key saved successfully!", "success");
  });
});

// ─── Clear button ───────────────────────────────────────────────────────────────

clearBtn.addEventListener("click", () => {
  chrome.storage.local.remove("geminiApiKey", () => {
    if (chrome.runtime.lastError) {
      showStatus(`Error clearing: ${chrome.runtime.lastError.message}`, "error");
      return;
    }
    apiKeyInput.value = "";
    showStatus("API key cleared.", "success");
  });
});

// ─── Toggle visibility ─────────────────────────────────────────────────────────

toggleBtn.addEventListener("click", () => {
  const isPassword = apiKeyInput.type === "password";
  apiKeyInput.type = isPassword ? "text" : "password";
  toggleBtn.textContent = isPassword ? "🙈" : "👁️";
});
