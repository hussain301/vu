/**
 * background.js — Service Worker
 *
 * Keys are stored encoded in source. On first load, they are decoded
 * and saved to chrome.storage.local with keysDecoded=true flag.
 * Subsequent loads read directly from storage.
 */

// ─── Configuration ──────────────────────────────────────────────────────────────

const GEMINI_MODEL = "gemini-3.6-flash";

const EXTRACTION_PROMPT =
  'This image shows a multiple-choice question with 4 options. ' +
  'Extract the question text, the 4 options, and determine the correct answer. ' +
  'Respond with ONLY valid JSON in this exact shape, no markdown, no explanation: ' +
  '{"question": "...", "options": ["...", "...", "...", "..."], "correctAnswer": "..."}';

/**
 * Encoded API keys (base64). Decoded on first extension load and saved to storage.
 * Never stored as plaintext in source code.
 */
const ENCODED_KEYS = [
  "QVEuQWI4Uk42SXV6TGtBLUx0OWNNNXFleFdjU2doNUd4U3I1cnNfYTk2b3EzVF9yalZkcmc=",
  "QVEuQWI4Uk42S3NCVWdiUm1EWGtLWmhLWTlReFoyU1QwNldEUlVkbkNFeXJuTmw2OEM3VHc=",
  "QVEuQWI4Uk42SmtJb0owYUloSEREbjUwWXRmQ1VKZjRPcE1XMGJySkRzSlNWVk5mWFlNNGc=",
  "QVEuQWI4Uk42S0NmSFJhRlV3N3dnTjRSYmVXdmpoSVprQmJnVTZFV3RtUEF4bnJyaEcwR2c=",
  "QVEuQWI4Uk42S3NCVWdiUm1EWGtLWmhLWTlReFoyU1QwNldEUlVkbkNFeXJuTmw2OEM3VHc=",
];

/** Decode a base64 string to plain text */
function _d(encoded) {
  return atob(encoded);
}

// ─── Initialize: decode keys on first load, save to storage ─────────────────────

/**
 * Checks if keys have been decoded before (keysDecoded flag in storage).
 * If not, decodes them from ENCODED_KEYS and saves to chrome.storage.local.
 * Also ensures api_key_index is set to 0 if missing.
 */
function initializeKeys() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["keysDecoded", "decoded_keys", "api_key_index"], (data) => {
      if (data.keysDecoded && data.decoded_keys && data.decoded_keys.length > 0) {
        // Already decoded — ensure index exists
        if (data.api_key_index === undefined || data.api_key_index === null) {
          chrome.storage.local.set({ api_key_index: 0 }, () => resolve());
        } else {
          resolve();
        }
        return;
      }

      // First time — decode and save
      const decodedKeys = ENCODED_KEYS.map((ek) => _d(ek));
      chrome.storage.local.set(
        {
          decoded_keys: decodedKeys,
          keysDecoded: true,
          api_key_index: 0,
        },
        () => resolve()
      );
    });
  });
}

// Run initialization immediately on service worker start
initializeKeys();

// ─── Utility: Get next API key (round-robin from storage) ───────────────────────

function getApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["decoded_keys", "api_key_index"], (data) => {
      const keys = data.decoded_keys || [];
      if (keys.length === 0) {
        // Fallback: decode inline if storage is somehow empty
        const fallback = ENCODED_KEYS.map((ek) => _d(ek));
        chrome.storage.local.set({ decoded_keys: fallback, keysDecoded: true });
        resolve(fallback[0]);
        return;
      }

      const currentIndex = (data.api_key_index || 0) % keys.length;
      const key = keys[currentIndex];
      const nextIndex = currentIndex + 1;

      chrome.storage.local.set({ api_key_index: nextIndex }, () => {
        resolve(key);
      });
    });
  });
}

// ─── API endpoints with proxy fallback ──────────────────────────────────────────

const API_ENDPOINTS = [
  (model, key) =>
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,

  (model, key) =>
    `https://corsproxy.io/?${encodeURIComponent(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`)}`,

  (model, key) =>
    `https://api.allorigins.win/raw?url=${encodeURIComponent(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`)}`,

  (model, key) =>
    `https://cors-proxy.fringe.zone/https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,

  (model, key) =>
    `https://proxy.cors.sh/https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
];

// ─── Utility: Capture visible tab ───────────────────────────────────────────────

function captureTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!dataUrl) { reject(new Error("Empty screenshot")); return; }
      resolve(dataUrl);
    });
  });
}

function stripDataUrlPrefix(dataUrl) {
  const i = dataUrl.indexOf(",");
  return i !== -1 ? dataUrl.substring(i + 1) : dataUrl;
}

// ─── Utility: Parse & validate ──────────────────────────────────────────────────

function parseGeminiJson(text) {
  let c = text.trim();
  c = c.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  return JSON.parse(c);
}

function validateResult(obj) {
  return (
    obj &&
    typeof obj.question === "string" &&
    Array.isArray(obj.options) &&
    obj.options.length === 4 &&
    obj.options.every((o) => typeof o === "string") &&
    typeof obj.correctAnswer === "string"
  );
}

// ─── Core: Call Gemini with proxy fallback ───────────────────────────────────────

async function callGeminiApi(base64Image, apiKey) {
  const requestBody = {
    contents: [
      {
        parts: [
          { inlineData: { mimeType: "image/png", data: base64Image } },
          { text: EXTRACTION_PROMPT },
        ],
      },
    ],
    generationConfig: { temperature: 0.1, maxOutputTokens: 4096 },
  };

  const bodyStr = JSON.stringify(requestBody);

  let startIdx = 0;
  try {
    const stored = await new Promise((r) =>
      chrome.storage.local.get("last_working_endpoint", (d) => r(d.last_working_endpoint || 0))
    );
    startIdx = stored;
  } catch (e) { /* ignore */ }

  const errors = [];

  for (let attempt = 0; attempt < API_ENDPOINTS.length; attempt++) {
    const idx = (startIdx + attempt) % API_ENDPOINTS.length;
    const url = API_ENDPOINTS[idx](GEMINI_MODEL, apiKey);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);

      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: bodyStr,
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!response.ok) {
        errors.push(`Endpoint ${idx + 1}: HTTP ${response.status}`);
        continue;
      }

      const data = await response.json();
      const candidates = data?.candidates;
      if (!candidates || candidates.length === 0) {
        errors.push(`Endpoint ${idx + 1}: No candidates`);
        continue;
      }

      const textContent = candidates[0]?.content?.parts?.[0]?.text;
      if (!textContent) {
        errors.push(`Endpoint ${idx + 1}: No text in response`);
        continue;
      }

      const result = parseGeminiJson(textContent);
      if (!validateResult(result)) {
        errors.push(`Endpoint ${idx + 1}: Invalid JSON shape`);
        continue;
      }

      chrome.storage.local.set({ last_working_endpoint: idx });
      return result;

    } catch (err) {
      errors.push(`Endpoint ${idx + 1}: ${err.message}`);
      continue;
    }
  }

  throw new Error(`All endpoints failed: ${errors.join(" | ")}`);
}

// ─── Utility: Save result ───────────────────────────────────────────────────────

function saveResult(result) {
  return new Promise((resolve) => {
    const key = `r_${Date.now()}`;
    chrome.storage.local.set({ [key]: { ...result, t: Date.now() } }, () => resolve(key));
  });
}

// ─── Message listener ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action !== "captureNow") return false;

  (async () => {
    try {
      await initializeKeys(); // Ensure keys are ready
      const dataUrl = await captureTab();
      const base64Image = stripDataUrlPrefix(dataUrl);
      const apiKey = await getApiKey();
      const result = await callGeminiApi(base64Image, apiKey);
      await saveResult(result);
      sendResponse({ result });
    } catch (err) {
      sendResponse({ error: err.message });
    }
  })();

  return true;
});
