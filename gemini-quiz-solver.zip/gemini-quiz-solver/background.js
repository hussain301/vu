/**
 * background.js — Service Worker
 *
 * Captures screenshot, sends to Gemini API with proxy fallback for restricted networks.
 * Tries direct Google API first, then falls back through CORS proxies if blocked.
 */

// ─── Configuration ──────────────────────────────────────────────────────────────

const GEMINI_MODEL = "gemini-3.6-flash";

const EXTRACTION_PROMPT =
  'This image shows a multiple-choice question with 4 options. ' +
  'Extract the question text, the 4 options, and determine the correct answer. ' +
  'Respond with ONLY valid JSON in this exact shape, no markdown, no explanation: ' +
  '{"question": "...", "options": ["...", "...", "...", "..."], "correctAnswer": "..."}';

/** Round-robin API keys */
const API_KEYS = [
  "AQ.Ab8RN6JCBS9hSUHWh6jlVK8t91YcjXuAfs4KfP5U_moS9p6eOQ",
  "AQ.Ab8RN6LeYSfF96qqAYXVTyQuywhzi8mar94VO6alM5xkj3l6FA",
  "AQ.Ab8RN6KE6WEdTLAULJIOlX3gGPCiz4yNaFUwjc0ALpWy3Ec1-A",
  "AQ.Ab8RN6JtQbovV3TAe5SqlXhm83OdW4gtJAsOsobJ9qEoAG8oSQ",
  "AQ.Ab8RN6ILQZWCxZ7n-GVXnDcSt8C41sUwiEGHKUma8XW0eysk9A",
];

/**
 * API endpoints to try in order — direct first, then proxies.
 * Each proxy wraps the Google API URL so it can bypass DNS/firewall blocks.
 */
const API_ENDPOINTS = [
  // 1. Direct Google API
  (model, key) =>
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,

  // 2. corsproxy.io — wraps any URL
  (model, key) =>
    `https://corsproxy.io/?${encodeURIComponent(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`)}`,

  // 3. allorigins (fetch mode)
  (model, key) =>
    `https://api.allorigins.win/raw?url=${encodeURIComponent(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`)}`,

  // 4. cors-anywhere compatible
  (model, key) =>
    `https://cors-proxy.fringe.zone/https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,

  // 5. Another proxy
  (model, key) =>
    `https://proxy.cors.sh/https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
];

// ─── Utility: Get next API key (round-robin, persisted) ─────────────────────────

function getApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get("api_key_index", (data) => {
      const currentIndex = (data.api_key_index || 0) % API_KEYS.length;
      const key = API_KEYS[currentIndex];
      const nextIndex = currentIndex + 1;
      chrome.storage.local.set({ api_key_index: nextIndex }, () => {
        resolve(key);
      });
    });
  });
}

// ─── Utility: Capture visible tab ───────────────────────────────────────────────

function captureTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!dataUrl) { reject(new Error("Empty screenshot")); return; }
      resolve(dataUrl);
    });
  });
}

function stripDataUrlPrefix(dataUrl) {
  const i = dataUrl.indexOf(",");
  return i !== -1 ? dataUrl.substring(i + 1) : dataUrl;
}

// ─── Utility: Parse & validate ──────────────────────────────────────────────────

function parseGeminiJson(text) {
  let c = text.trim();
  c = c.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  return JSON.parse(c);
}

function validateResult(obj) {
  return (
    obj &&
    typeof obj.question === "string" &&
    Array.isArray(obj.options) &&
    obj.options.length === 4 &&
    obj.options.every((o) => typeof o === "string") &&
    typeof obj.correctAnswer === "string"
  );
}

// ─── Core: Call Gemini with proxy fallback ───────────────────────────────────────

/**
 * Tries each endpoint in order. If one fails (network block, CORS, timeout),
 * falls through to the next. Saves the last working endpoint index for next time.
 */
async function callGeminiApi(base64Image, apiKey) {
  const requestBody = {
    contents: [
      {
        parts: [
          { inlineData: { mimeType: "image/png", data: base64Image } },
          { text: EXTRACTION_PROMPT },
        ],
      },
    ],
    generationConfig: { temperature: 0.1, maxOutputTokens: 4096 },
  };

  const bodyStr = JSON.stringify(requestBody);

  // Try to use the last working endpoint first
  let startIdx = 0;
  try {
    const stored = await new Promise((r) =>
      chrome.storage.local.get("last_working_endpoint", (d) => r(d.last_working_endpoint || 0))
    );
    startIdx = stored;
  } catch (e) { /* ignore */ }

  const errors = [];

  for (let attempt = 0; attempt < API_ENDPOINTS.length; attempt++) {
    const idx = (startIdx + attempt) % API_ENDPOINTS.length;
    const url = API_ENDPOINTS[idx](GEMINI_MODEL, apiKey);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000); // 15s timeout

      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: bodyStr,
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!response.ok) {
        const errText = await response.text();
        errors.push(`Endpoint ${idx + 1}: HTTP ${response.status}`);
        continue;
      }

      const data = await response.json();
      const candidates = data?.candidates;
      if (!candidates || candidates.length === 0) {
        errors.push(`Endpoint ${idx + 1}: No candidates`);
        continue;
      }

      const textContent = candidates[0]?.content?.parts?.[0]?.text;
      if (!textContent) {
        errors.push(`Endpoint ${idx + 1}: No text in response`);
        continue;
      }

      const result = parseGeminiJson(textContent);
      if (!validateResult(result)) {
        errors.push(`Endpoint ${idx + 1}: Invalid JSON shape`);
        continue;
      }

      // Save this as the working endpoint for next time
      chrome.storage.local.set({ last_working_endpoint: idx });
      return result;

    } catch (err) {
      errors.push(`Endpoint ${idx + 1}: ${err.message}`);
      continue;
    }
  }

  throw new Error(`All endpoints failed: ${errors.join(" | ")}`);
}

// ─── Utility: Save result ───────────────────────────────────────────────────────

function saveResult(result) {
  return new Promise((resolve) => {
    const key = `r_${Date.now()}`;
    chrome.storage.local.set({ [key]: { ...result, t: Date.now() } }, () => resolve(key));
  });
}

// ─── Message listener ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action !== "captureNow") return false;

  (async () => {
    try {
      const dataUrl = await captureTab();
      const base64Image = stripDataUrlPrefix(dataUrl);
      const apiKey = await getApiKey();
      const result = await callGeminiApi(base64Image, apiKey);
      await saveResult(result);
      sendResponse({ result });
    } catch (err) {
      sendResponse({ error: err.message });
    }
  })();

  return true;
});
